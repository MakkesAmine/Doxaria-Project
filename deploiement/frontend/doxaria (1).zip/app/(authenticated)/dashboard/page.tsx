"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, PieChart, Pill, TrendingUp } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export default function Dashboard() {
  const [adherenceProgress, setAdherenceProgress] = useState(0)

  useEffect(() => {
    const timer = setTimeout(() => setAdherenceProgress(92), 500)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Welcome, John Doe</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Prescriptions</CardTitle>
            <Pill className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-muted-foreground">2 expiring soon</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Refills</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Next refill in 2 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Medication Adherence</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{adherenceProgress}%</div>
            <Progress value={adherenceProgress} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">Last 30 days</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Prescriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Amoxicillin</p>
                  <p className="text-sm text-muted-foreground">Prescribed on: 2023-05-15</p>
                </div>
                <Button variant="outline">View Details</Button>
              </li>
              <li className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Lisinopril</p>
                  <p className="text-sm text-muted-foreground">Prescribed on: 2023-05-10</p>
                </div>
                <Button variant="outline">View Details</Button>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Reminders</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Take Metformin</p>
                  <p className="text-sm text-muted-foreground">Today at 8:00 PM</p>
                </div>
                <Button variant="outline">Mark as Done</Button>
              </li>
              <li className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Refill Atorvastatin</p>
                  <p className="text-sm text-muted-foreground">Tomorrow at 10:00 AM</p>
                </div>
                <Button variant="outline">Set Reminder</Button>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Medication Adherence Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] flex items-center justify-center">
            <PieChart className="h-32 w-32 text-blue-500" />
          </div>
          <div className="text-center mt-4">
            <p className="text-lg font-medium">Your adherence is better than 80% of users</p>
            <p className="text-sm text-muted-foreground">Keep up the good work!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

