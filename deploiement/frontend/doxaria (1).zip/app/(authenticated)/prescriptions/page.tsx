"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PrescriptionManagement() {
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false)

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Prescription Management</h1>
        <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
          <DialogTrigger asChild>
            <Button>Upload New Prescription</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Upload New Prescription</DialogTitle>
              <DialogDescription>
                Upload a photo or PDF of your prescription. We'll process it and add it to your records.
              </DialogDescription>
            </DialogHeader>
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <Label htmlFor="prescription">Prescription File</Label>
              <Input id="prescription" type="file" />
            </div>
            <DialogFooter>
              <Button type="submit">Upload</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filter Prescriptions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="doctor">Doctor</Label>
              <Input id="doctor" placeholder="Filter by doctor" />
            </div>
            <div>
              <Label htmlFor="date">Date</Label>
              <Input id="date" type="date" />
            </div>
            <div>
              <Label htmlFor="medication">Medication</Label>
              <Input id="medication" placeholder="Filter by medication" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="active">
        <TabsList>
          <TabsTrigger value="active">Active Prescriptions</TabsTrigger>
          <TabsTrigger value="past">Past Prescriptions</TabsTrigger>
        </TabsList>
        <TabsContent value="active">
          <Card>
            <CardHeader>
              <CardTitle>Active Prescriptions</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Medication</TableHead>
                    <TableHead>Doctor</TableHead>
                    <TableHead>Issue Date</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Amoxicillin</TableCell>
                    <TableCell>Dr. Smith</TableCell>
                    <TableCell>2023-05-15</TableCell>
                    <TableCell>2023-06-15</TableCell>
                    <TableCell>
                      <Button variant="outline" className="mr-2">
                        View
                      </Button>
                      <Button variant="outline">Refill</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Lisinopril</TableCell>
                    <TableCell>Dr. Johnson</TableCell>
                    <TableCell>2023-05-10</TableCell>
                    <TableCell>2023-11-10</TableCell>
                    <TableCell>
                      <Button variant="outline" className="mr-2">
                        View
                      </Button>
                      <Button variant="outline">Refill</Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="past">
          <Card>
            <CardHeader>
              <CardTitle>Past Prescriptions</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Medication</TableHead>
                    <TableHead>Doctor</TableHead>
                    <TableHead>Issue Date</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Ibuprofen</TableCell>
                    <TableCell>Dr. Brown</TableCell>
                    <TableCell>2023-01-15</TableCell>
                    <TableCell>2023-02-15</TableCell>
                    <TableCell>
                      <Button variant="outline">View</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Omeprazole</TableCell>
                    <TableCell>Dr. Davis</TableCell>
                    <TableCell>2023-02-10</TableCell>
                    <TableCell>2023-03-10</TableCell>
                    <TableCell>
                      <Button variant="outline">View</Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

