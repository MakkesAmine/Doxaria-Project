import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function Recommendations() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Smart Drug Recommendations</h1>

      <Card>
        <CardHeader>
          <CardTitle>Alternative for: Amoxicillin</CardTitle>
          <CardDescription>Based on your current prescription</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Medication</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Availability</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>Augmentin</TableCell>
                <TableCell>Brand Alternative</TableCell>
                <TableCell>$25.99</TableCell>
                <TableCell>In Stock</TableCell>
                <TableCell>
                  <Button variant="outline">View Details</Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Amoxicillin-Clavulanate</TableCell>
                <TableCell>Generic Alternative</TableCell>
                <TableCell>$15.99</TableCell>
                <TableCell>In Stock</TableCell>
                <TableCell>
                  <Button variant="outline">View Details</Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Nearby Pharmacies with Amoxicillin in Stock</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Pharmacy</TableHead>
                <TableHead>Distance</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>CVS Pharmacy</TableCell>
                <TableCell>0.5 miles</TableCell>
                <TableCell>$20.99</TableCell>
                <TableCell>
                  <Button variant="outline">Reserve</Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Walgreens</TableCell>
                <TableCell>1.2 miles</TableCell>
                <TableCell>$22.99</TableCell>
                <TableCell>
                  <Button variant="outline">Reserve</Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

