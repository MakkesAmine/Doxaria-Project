import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const routes = [
  { name: "Landing Page", path: "/" },
  { name: "Login", path: "/login" },
  { name: "Signup", path: "/signup" },
  { name: "Dashboard", path: "/dashboard" },
  { name: "Prescriptions", path: "/prescriptions" },
  { name: "Recommendations", path: "/recommendations" },
  { name: "AI Assistant", path: "/chat" },
  { name: "Pharmacies", path: "/pharmacies" },
  { name: "Settings", path: "/settings" },
  { name: "Route Access", path: "/route-access" },
]

export default function RouteAccess() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Route Access</h1>
      <Card>
        <CardHeader>
          <CardTitle>All Routes</CardTitle>
          <CardDescription>Click on a button to navigate to the corresponding page</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {routes.map((route) => (
              <Link href={route.path} key={route.path}>
                <Button variant="outline" className="w-full">
                  {route.name}
                </Button>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

