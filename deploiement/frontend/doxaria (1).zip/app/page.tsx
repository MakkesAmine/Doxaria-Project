import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-white">
      <header className="container mx-auto px-4 py-8">
        <nav className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">Doxaria</h1>
          <div>
            <Button variant="outline" className="mr-2">
              <Link href="/login">Login</Link>
            </Button>
            <Button>
              <Link href="/signup">Sign Up</Link>
            </Button>
          </div>
        </nav>
      </header>

      <main className="container mx-auto px-4 py-16">
        <section className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Manage Your Prescriptions Efficiently</h2>
          <p className="text-xl mb-8">
            Doxaria helps you digitize, track, and optimize your medical prescriptions with AI-powered assistance.
          </p>
          <Button size="lg">Get Started</Button>
        </section>

        <section className="grid md:grid-cols-3 gap-8 mb-16">
          <Card>
            <CardHeader>
              <CardTitle>Automatic Digitization</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Upload your prescriptions and let our AI convert them into digital records instantly.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Smart Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Get intelligent suggestions for alternative medications and nearby pharmacies.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>AI-Powered Assistance</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Chat with our AI assistant for instant answers to your medication queries.</p>
            </CardContent>
          </Card>
        </section>

        <section className="text-center mb-16">
          <h3 className="text-2xl font-bold mb-4">How Doxaria Works</h3>
          {/* Add illustrations or steps here */}
        </section>

        <section className="bg-blue-50 rounded-lg p-8">
          <h3 className="text-2xl font-bold mb-4 text-center">What Our Users Say</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>John Doe</CardTitle>
                <CardDescription>Patient</CardDescription>
              </CardHeader>
              <CardContent>
                <p>"Doxaria has made managing my prescriptions so much easier. I love the AI chat feature!"</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Jane Smith</CardTitle>
                <CardDescription>Caregiver</CardDescription>
              </CardHeader>
              <CardContent>
                <p>"As a caregiver, Doxaria helps me keep track of multiple prescriptions effortlessly."</p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <footer className="bg-blue-600 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2025 Doxaria. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

